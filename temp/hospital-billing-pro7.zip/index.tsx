// Fix: Added export {} to turn this file into a module and prevent global namespace collisions.
export {};

declare const bootstrap: any;
declare const Swal: any;

interface InventoryItem {
  id: number;
  name: string;
  price: number | string;
  type?: string;
  category?: string;
  strength?: string;
}

interface BillItem extends InventoryItem {
  qty: number;
  duration?: number;
  frequency?: number;
  dosePerTime?: number;
  subtotal: number;
}

class MediBillApp {
  private inventory: Record<string, InventoryItem[]> = {};
  private bill: BillItem[] = [];
  private currentView: string = "home";
  private currentCatOPIdx: number = 0;
  private currentCatIPIdx: number = 0;
  private catModeOP: 'grid' | 'carousel' = 'grid';
  private catModeIP: 'grid' | 'carousel' = 'grid';
  
  private entryModal: any;
  private activeDosageItem: InventoryItem | null = null;
  private activeEditItem: InventoryItem | null = null;

  private inpatientCats: string[] = [
    "Medicine", "Laboratory", "Blood", "Surgery, O.R. & Delivery", "Registration Fees",
    "Physical Therapy", "Limb and Brace", "Food", "Halo, O2, NO2, etc.",
    "Orthopedic, S.Roll, etc.", "IV.'s", "Discharge Medicine", "Procedures", "Seat & Ad. Fee"
  ];

  private outpatientCats: string[] = [];
  private nextItemId: number = 1;

  constructor() {
    this.init();
  }

  private async init() {
    const modalEl = document.getElementById('entryModal');
    if (modalEl) this.entryModal = new bootstrap.Modal(modalEl);
    
    await this.loadInitialData();
    this.outpatientCats = Object.keys(this.inventory).sort();
    
    this.nextItemId = 1;
    Object.values(this.inventory).forEach(items => {
      items.forEach(item => {
        if (typeof item.id === 'number' && item.id >= this.nextItemId) {
          this.nextItemId = item.id + 1;
        }
      });
    });

    this.setupEventListeners();
    this.renderAll();
    
    this.toggleCatMode('op', 'grid');
    this.toggleCatMode('ip', 'grid');
    
    this.setupKeyboardNav();
    this.setupSwipeGestures(); // Call swipe gestures setup here
    this.syncSharedUI();
    this.startClock();

    const homeNavButton = document.getElementById('nav-home');
    if (homeNavButton) {
      this.switchView('home', homeNavButton);
    }
  }

  private setupEventListeners() {
    document.getElementById('brand-logo')?.addEventListener('click', () => location.reload());
    
    document.querySelectorAll('.nav-btn').forEach(btn => {
      btn.addEventListener('click', (event) => {
        const targetBtn = event.currentTarget as HTMLElement;
        const view = targetBtn.dataset.view;
        if (view) this.switchView(view, targetBtn);
      });
    });

    document.getElementById('home-view-outpatient-btn')?.addEventListener('click', () => {
        const btn = document.getElementById('nav-outpatient');
        if (btn) this.switchView('outpatient', btn);
    });
    document.getElementById('home-view-inpatient-btn')?.addEventListener('click', () => {
        const btn = document.getElementById('nav-inpatient');
        if (btn) this.switchView('inpatient', btn);
    });

    document.getElementById('close-dosage-icon')?.addEventListener('click', () => this.closeDosage());
    document.getElementById('add-to-statement-button')?.addEventListener('click', () => this.addDosageToBill());

    ['dose-qty', 'dose-days', 'dose-type', 'dose-freq', 'service-qty'].forEach(id => {
        document.getElementById(id)?.addEventListener('input', () => this.calcDosage());
        document.getElementById(id)?.addEventListener('change', () => this.calcDosage());
    });

    document.getElementById('op-search')?.addEventListener('input', () => this.renderItems('outpatient'));
    document.getElementById('op-carousel-prev-btn')?.addEventListener('click', () => this.carouselOPPrev());
    document.getElementById('op-carousel-next-btn')?.addEventListener('click', () => this.carouselOPNext());
    document.getElementById('op-toggle-grid-btn')?.addEventListener('click', () => this.toggleCatMode('op', 'grid'));
    document.getElementById('op-reset-bill-btn')?.addEventListener('click', () => this.clearBill());
    document.getElementById('op-finalize-bill-btn')?.addEventListener('click', () => this.finalize());

    document.getElementById('ip-search')?.addEventListener('input', () => this.renderItems('inpatient'));
    document.getElementById('ip-carousel-prev-btn')?.addEventListener('click', () => this.carouselPrev());
    document.getElementById('ip-carousel-next-btn')?.addEventListener('click', () => this.carouselNext());
    document.getElementById('ip-toggle-grid-btn')?.addEventListener('click', () => this.toggleCatMode('ip', 'grid'));
    document.getElementById('ip-reset-bill-btn')?.addEventListener('click', () => this.clearBill());
    document.getElementById('ip-finalize-bill-btn')?.addEventListener('click', () => this.finalize());

    document.getElementById('pricing-search')?.addEventListener('input', () => this.renderPricing());
    document.getElementById('pricing-add-entry-btn')?.addEventListener('click', () => this.openEntryModal());
    document.getElementById('pricing-save-entry-btn')?.addEventListener('click', () => this.savePricingEntry());
    document.getElementById('pricing-export-btn')?.addEventListener('click', () => this.exportDatabase());
    document.getElementById('pricing-import-btn')?.addEventListener('click', () => document.getElementById('pricing-file-input')?.click());
    document.getElementById('pricing-file-input')?.addEventListener('change', (e) => this.importDatabase(e));

    const handleCatCardClick = (e: Event, view: 'op' | 'ip') => {
        const card = (e.target as HTMLElement).closest('.cat-card') as HTMLElement;
        if (card) {
            const idx = parseInt(card.dataset.catIndex || '-1');
            if (idx > -1) {
                if (view === 'op') this.selectOPCat(idx);
                else this.selectIPCat(idx);
            }
        }
    };
    document.getElementById('op-cat-grid')?.addEventListener('click', (e) => handleCatCardClick(e, 'op'));
    document.getElementById('ip-cat-grid')?.addEventListener('click', (e) => handleCatCardClick(e, 'ip'));


    const handleItemClick = (e: Event) => {
        const row = (e.target as HTMLElement).closest('.item-entry');
        if (row) {
            const hrow = row as HTMLElement;
            // Only trigger dosage if not clicking edit/delete icons
            if (!(e.target as HTMLElement).classList.contains('icon-action')) {
              this.openDosage(hrow.dataset.catName || '', hrow.dataset.itemName || '');
            }
        }
    };
    document.getElementById('op-items-grid')?.addEventListener('click', handleItemClick);
    document.getElementById('ip-items-grid')?.addEventListener('click', handleItemClick);

    document.getElementById('pricing-items-target')?.addEventListener('click', (e) => {
        const target = e.target as HTMLElement;
        const row = target.closest('.item-entry') as HTMLElement;
        if (!row) return;
        const id = parseInt(row.dataset.itemId || '0');
        const cat = row.dataset.catName || '';
        const item = this.inventory[cat]?.find(i => i.id === id);
        if (!item) return;

        if (target.classList.contains('edit')) this.openEntryModal(item);
        if (target.classList.contains('delete')) this.deletePricingEntry(item);
    });

    document.getElementById('medicine-tags-list')?.addEventListener('click', (event) => {
      const target = event.target as HTMLElement;
      const itemName = target.dataset.itemName; // Access directly from the <i> tag
      if (itemName) {
        this.removeByName(itemName);
      }
    });

    const handleRemove = (e: Event) => {
        const target = e.target as HTMLElement;
        if (target.classList.contains('remove-btn') || target.closest('.remove-btn')) {
            const row = target.closest('.bill-line') as HTMLElement;
            this.removeFromBill(parseInt(row.dataset.billIndex || '0'));
        }
    };
    document.getElementById('bill-list-target')?.addEventListener('click', handleRemove);
    document.getElementById('ip-bill-summary')?.addEventListener('click', handleRemove);
  }

  private startClock() {
    const el = document.getElementById('live-clock');
    if (el) setInterval(() => el.innerText = new Date().toLocaleTimeString('en-GB'), 1000);
  }

  private async loadInitialData() {
    try {
      const res = await fetch('med.json');
      if (res.ok) {
        const data = await res.json();
        this.inventory = {};
        data.forEach((item: any) => {
          const cat = item.category || "General";
          if (!this.inventory[cat]) this.inventory[cat] = [];
          item.id = item.id || this.nextItemId++;
          this.nextItemId = Math.max(this.nextItemId, item.id + 1);
          this.inventory[cat].push(item);
        });
      }
    } catch (e) { console.warn("Load error", e); }
    this.inpatientCats.forEach(c => { if(!this.inventory[c]) this.inventory[c] = []; });
  }

  private setupKeyboardNav() {
    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') this.closeDosage();
    });
  }

  private setupSwipeGestures() {
    const attachSwipe = (id: string, onNext: () => void, onPrev: () => void) => {
        const el = document.getElementById(id);
        if (!el) return;
        let startX = 0;
        el.addEventListener('touchstart', (e) => startX = e.changedTouches[0].screenX, {passive: true});
        el.addEventListener('touchend', (e) => {
            const endX = e.changedTouches[0].screenX;
            const swipeThreshold = 50; // pixels
            if (startX - endX > swipeThreshold) onNext(); // Swipe Left (Next)
            if (endX - startX > swipeThreshold) onPrev(); // Swipe Right (Prev)
        }, {passive: true});
    };
    attachSwipe('op-caro-box', () => this.carouselOPNext(), () => this.carouselOPPrev());
    attachSwipe('ip-caro-box', () => this.carouselNext(), () => this.carouselPrev());
  }

  public switchView(view: string, btn: HTMLElement) {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    this.currentView = view;
    ['home', 'outpatient', 'inpatient', 'pricing'].forEach(v => {
        const el = document.getElementById(`view-${v}`);
        if (el) el.style.display = v === view ? 'block' : 'none';
    });
    
    // Always reset to grid view when switching main tabs
    if (view === 'outpatient') this.toggleCatMode('op', 'grid');
    if (view === 'inpatient') this.toggleCatMode('ip', 'grid');

    this.closeDosage(); // Ensure dosage panel is closed when switching views
    this.syncSharedUI();
    this.renderAll();
  }

  private syncSharedUI() {
    const container = document.getElementById('shared-interactive-container');
    if (!container) return; 

    // Find the main-content element within the current view
    const viewEl = document.getElementById(`view-${this.currentView}`);
    const mainContentEl = viewEl?.querySelector('.main-content');
    const searchBox = mainContentEl?.querySelector('.search-input-box');
        
    if (this.currentView === 'outpatient' || this.currentView === 'inpatient') {
        if (searchBox && mainContentEl) { // Ensure both elements are found
            container.style.display = 'block';
            // Insert the container into mainContentEl, before the searchBox
            mainContentEl.insertBefore(container, searchBox); 
            
            // Adjust visibility of medicine tags based on selected category
            const tagsDiv = document.getElementById('medicine-tags');
            if (tagsDiv) {
                const cats = this.currentView === 'outpatient' ? this.outpatientCats : this.inpatientCats;
                const currentCatIndex = this.currentView === 'outpatient' ? this.currentCatOPIdx : this.currentCatIPIdx;
                const currentCatName = cats[currentCatIndex];
                tagsDiv.style.display = (currentCatName === 'Medicine' || currentCatName === 'Discharge Medicine') ? 'flex' : 'none';
            }
        } else {
            // If mainContentEl or searchBox is not found, hide the container
            container.style.display = 'none';
        }
    } else {
        container.style.display = 'none';
    }
  }

  public toggleCatMode(view: 'op' | 'ip', mode: 'grid' | 'carousel') {
    const gridEl = document.getElementById(`${view}-cat-grid`);
    const caroEl = document.getElementById(`${view}-caro-box`);
    
    if (view === 'op') this.catModeOP = mode; else this.catModeIP = mode;

    if (gridEl) gridEl.style.display = mode === 'grid' ? 'grid' : 'none'; // Changed to grid
    if (caroEl) caroEl.style.display = mode === 'carousel' ? 'block' : 'none';
    
    this.closeDosage(); // Ensure dosage panel is closed when changing category mode
    this.renderAll();
  }

  private renderAll() {
    if (this.currentView === 'outpatient') {
      this.renderOPGrid();
      this.renderOPCarousel();
      this.renderItems('outpatient');
      this.updateReceipt('op');
      this.updateMedicineTags(); // Ensure tags are updated with current bill
    } else if (this.currentView === 'inpatient') {
      this.renderIPGrid();
      this.renderIPCarousel();
      this.renderItems('inpatient');
      this.updateReceipt('ip');
    } else if (this.currentView === 'pricing') {
      this.renderPricing();
      this.populatePricingFilters();
    }
  }

  private renderOPGrid() {
    const el = document.getElementById('op-cat-grid');
    if (!el) return;
    el.innerHTML = this.outpatientCats.map((cat, idx) => `
      <div class="cat-card ${this.currentCatOPIdx === idx ? 'active' : ''}" data-cat-index="${idx}">
        <span class="name">${cat}</span>
        <span class="info">${this.inventory[cat]?.length || 0} ITEMS IN GROUP</span>
      </div>`).join('');
  }

  private renderOPCarousel() {
    const cat = this.outpatientCats[this.currentCatOPIdx];
    const nameEl = document.getElementById('op-caro-name');
    const statsEl = document.getElementById('op-caro-stats');
    if (nameEl) nameEl.innerText = cat || '---';
    if (statsEl) statsEl.innerText = `${this.inventory[cat]?.length || 0} indexed items`;
  }

  public selectOPCat(idx: number) { this.currentCatOPIdx = idx; this.toggleCatMode('op', 'carousel'); }
  public carouselOPNext() { this.currentCatOPIdx = (this.currentCatOPIdx + 1) % this.outpatientCats.length; this.renderOPCarousel(); this.renderItems('outpatient'); }
  public carouselOPPrev() { this.currentCatOPIdx = (this.currentCatOPIdx - 1 + this.outpatientCats.length) % this.outpatientCats.length; this.renderOPCarousel(); this.renderItems('outpatient'); }

  private renderIPGrid() {
    const el = document.getElementById('ip-cat-grid');
    if (!el) return;
    el.innerHTML = this.inpatientCats.map((cat, idx) => `
      <div class="cat-card ${this.currentCatIPIdx === idx ? 'active' : ''}" data-cat-index="${idx}">
        <span class="name">${cat}</span>
        <span class="info">${this.inventory[cat]?.length || 0} ENTRIES</span>
      </div>`).join('');
  }

  private renderIPCarousel() {
    const cat = this.inpatientCats[this.currentCatIPIdx];
    const nameEl = document.getElementById('ip-caro-name');
    const statsEl = document.getElementById('ip-caro-stats');
    if (nameEl) nameEl.innerText = cat || '---';
    if (statsEl) statsEl.innerText = `${this.inventory[cat]?.length || 0} services`;
  }

  public selectIPCat(idx: number) { this.currentCatIPIdx = idx; this.toggleCatMode('ip', 'carousel'); }
  public carouselNext() { this.currentCatIPIdx = (this.currentCatIPIdx + 1) % this.inpatientCats.length; this.renderIPCarousel(); this.renderItems('inpatient'); }
  public carouselPrev() { this.currentCatIPIdx = (this.currentCatIPIdx - 1 + this.inpatientCats.length) % this.inpatientCats.length; this.renderIPCarousel(); this.renderItems('inpatient'); }

  public openDosage(cat: string, name: string) {
    const item = this.inventory[cat]?.find(i => i.name === name);
    if (!item) return;
    this.activeDosageItem = { ...item, category: cat };
    
    const panel = document.getElementById('dosage-panel');
    if (panel) panel.style.display = 'block';
    
    const title = document.getElementById('dosage-item-name');
    if (title) title.innerText = item.name;
    
    // Determine if it's a medicine type based on category or item.type
    const isMed = cat === 'Medicine' || cat === 'Discharge Medicine' || 
                  ['Injection', 'Tablet', 'Capsule', 'Syrup'].includes(item.type || '');
    const medFields = document.getElementById('dosage-fields-medicine');
    const serFields = document.getElementById('dosage-fields-service');
    
    if (medFields) medFields.style.display = isMed ? 'grid' : 'none'; // Changed to grid
    if (serFields) serFields.style.display = isMed ? 'none' : 'grid'; // Changed to grid
    
    // Reset dosage panel values when opening
    (document.getElementById('dose-qty') as HTMLInputElement).value = "1.0";
    (document.getElementById('dose-days') as HTMLInputElement).value = "7";
    (document.getElementById('dose-type') as HTMLSelectElement).value = item.type || "Tablet"; // Set default type if available
    (document.getElementById('dose-freq') as HTMLSelectElement).value = "3"; // Default to TID
    (document.getElementById('service-qty') as HTMLInputElement).value = "1";

    this.calcDosage();
  }

  public closeDosage() {
    const panel = document.getElementById('dosage-panel');
    if (panel) panel.style.display = 'none';
    this.activeDosageItem = null;
  }

  public calcDosage() {
    if (!this.activeDosageItem) return;
    let totalQty = 0;
    const medFields = document.getElementById('dosage-fields-medicine');
    const isMed = medFields && medFields.style.display !== 'none';
    if (isMed) {
        const qty = parseFloat((document.getElementById('dose-qty') as HTMLInputElement).value) || 0;
        const freq = parseFloat((document.getElementById('dose-freq') as HTMLSelectElement).value) || 0;
        const days = parseInt((document.getElementById('dose-days') as HTMLInputElement).value) || 0;
        totalQty = qty * freq * days;
    } else {
        totalQty = parseFloat((document.getElementById('service-qty') as HTMLInputElement).value) || 1;
    }
    const price = typeof this.activeDosageItem.price === 'number' ? this.activeDosageItem.price : parseFloat(String(this.activeDosageItem.price).replace(/[^\d.]/g, '') || '0');
    const display = document.getElementById('dose-total-display');
    if (display) display.innerText = "৳ " + (totalQty * price).toLocaleString('en-IN', { minimumFractionDigits: 2 });
  }

  public addDosageToBill() {
    if (!this.activeDosageItem) return;
    const subtotal = parseFloat(document.getElementById('dose-total-display')?.innerText.replace(/[৳, ]/g, '') || '0');
    let totalQty = 0;
    const medFields = document.getElementById('dosage-fields-medicine');
    const isMed = medFields && medFields.style.display !== 'none';
    if (isMed) {
        totalQty = (parseFloat((document.getElementById('dose-qty') as HTMLInputElement).value) || 0) * 
                   (parseFloat((document.getElementById('dose-freq') as HTMLSelectElement).value) || 0) * 
                   (parseInt((document.getElementById('dose-days') as HTMLInputElement).value) || 0);
    } else {
        totalQty = parseFloat((document.getElementById('service-qty') as HTMLInputElement).value) || 1;
    }
    this.bill.push({ ...this.activeDosageItem, qty: totalQty, subtotal });
    this.updateReceipt(this.currentView === 'outpatient' ? 'op' : 'ip');
    this.updateMedicineTags();
    this.closeDosage();
    
    Swal.fire({ 
        toast: true, position: 'top-end', icon: 'success', title: 'ADDED TO STATEMENT', showConfirmButton: false, timer: 1200, background: '#121214', color: '#fff' 
    });
  }

  private updateMedicineTags() {
      const container = document.getElementById('medicine-tags-list');
      if (!container) return; // Ensure container exists
      const meds = this.bill.filter(i => i.category === "Medicine" || i.category === "Discharge Medicine");
      container.innerHTML = meds.map(m => `<span class="tag-pill">${m.name}<i class="fas fa-times ms-1 cursor-pointer" data-item-name="${m.name.replace(/'/g, "\\'")}"></i></span>`).join('');
  }

  public removeByName(name: string) { 
    const idx = this.bill.findIndex(i => i.name === name); 
    if (idx > -1) {
      this.removeFromBill(idx); 
    }
  }

  public renderItems(view: string) {
    const el = document.getElementById(view === 'outpatient' ? 'op-items-grid' : 'ip-items-grid');
    if (!el) return;
    const searchIn = document.getElementById(view === 'outpatient' ? 'op-search' : 'ip-search') as HTMLInputElement;
    const search = searchIn ? searchIn.value.toLowerCase() : '';
    const cats = view === 'outpatient' ? this.outpatientCats : this.inpatientCats;
    const cat = cats[view === 'outpatient' ? this.currentCatOPIdx : this.currentCatIPIdx];
    const items = (this.inventory[cat] || []).filter(i => i.name.toLowerCase().includes(search));
    
    if (items.length === 0) { 
      el.innerHTML = `<div class="empty-bill-placeholder">NO MATCHES</div>`; 
      return; 
    }

    el.innerHTML = items.map(i => `
      <div class="item-entry" data-cat-name="${cat}" data-item-name="${i.name}">
          <div class="details"><span class="name">${i.name}</span><span class="meta">${i.type || 'Service'}</span></div>
          <span class="price-label"><span>৳</span>${i.price}</span>
      </div>`).join('');
  }

  public updateReceipt(prefix: string) {
    const list = document.getElementById(prefix === 'op' ? 'bill-list-target' : 'ip-bill-summary');
    const totalEl = document.getElementById(`${prefix}-total-val`);
    if (!list || !totalEl) return;
    
    let total = 0;
    if (this.bill.length === 0) {
        list.innerHTML = `<div class="empty-bill-placeholder">STATEMENT EMPTY</div>`;
        totalEl.innerText = "0.00";
        return;
    }
    
    const categories = [...new Set(this.bill.map(i => i.category))].sort();
    list.innerHTML = categories.map(cat => {
        const items = this.bill.filter(i => i.category === cat);
        total += items.reduce((s, i) => s + i.subtotal, 0);
        return `<div class="bill-group"><div class="bill-group-header"><span class="cat">${cat}</span></div>${items.map(item => `<div class="bill-line" data-bill-index="${this.bill.indexOf(item)}"><span class="n">${item.name} <span class="small opacity-50 fw-400">x${item.qty}</span></span><span class="v">৳ ${item.subtotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span><i class="fas fa-times remove-btn ms-2"></i></div>`).join('')}</div>`;
    }).join('');
    totalEl.innerText = total.toLocaleString('en-IN', { minimumFractionDigits: 2 });
  }

  public removeFromBill(idx: number) { this.bill.splice(idx, 1); this.updateReceipt(this.currentView === 'outpatient' ? 'op' : 'ip'); this.updateMedicineTags(); }
  public clearBill() { this.bill = []; this.renderAll(); }

  public renderPricing() {
    const el = document.getElementById('pricing-items-target');
    if (!el) return;
    const searchIn = document.getElementById('pricing-search') as HTMLInputElement;
    const search = searchIn ? searchIn.value.toLowerCase() : '';
    let flat: InventoryItem[] = [];
    Object.entries(this.inventory).forEach(([cat, items]) => {
        items.forEach(i => { if (i.name.toLowerCase().includes(search) || (cat && cat.toLowerCase().includes(search))) flat.push({ ...i, category: cat }); });
    });

    if (flat.length === 0) { 
      el.innerHTML = `<div class="empty-bill-placeholder">No records matching "${search}".</div>`; 
      return; 
    }

    el.innerHTML = flat.map(i => `
      <div class="item-entry" data-item-id="${i.id}" data-cat-name="${i.category || ''}" data-item-name="${i.name}">
          <div class="details"><span class="name">${i.name}</span><span class="meta">${i.category || 'N/A'} &bull; ${i.type || 'N/A'}</span></div>
          <div class="right-side">
            <span class="price-label"><span>৳</span>${i.price}</span>
            <i class="fas fa-edit icon-action edit" title="Edit Record"></i>
            <i class="fas fa-trash-alt icon-action delete" title="Delete Record"></i>
          </div>
      </div>`).join('');
  }

  private populatePricingFilters() {
    const el = document.getElementById('entry-cat') as HTMLSelectElement;
    if (!el) return;
    el.innerHTML = '';
    const allCats = new Set<string>();
    Object.keys(this.inventory).forEach(cat => allCats.add(cat));
    this.inpatientCats.forEach(cat => allCats.add(cat));

    const sortedCats = Array.from(allCats).sort();
    sortedCats.forEach(c => el.add(new Option(c, c)));
  }

  public openEntryModal(item: InventoryItem | null = null) {
    this.activeEditItem = item;
    const ni = document.getElementById('entry-name') as HTMLInputElement;
    const ci = document.getElementById('entry-cat') as HTMLSelectElement;
    const pi = document.getElementById('entry-price') as HTMLInputElement;
    const ti = document.getElementById('entry-type') as HTMLSelectElement;
    
    if (ni && ci && pi && ti) { // Ensure elements exist
        if (item) {
            ni.value = item.name;
            ci.value = item.category || '';
            pi.value = String(item.price).replace(/[^\d.]/g, ''); // Clean price string
            ti.value = item.type || 'Medicine';
            (document.getElementById('entryModalLabel') as HTMLElement).innerText = 'EDIT DATABASE RECORD';
        } else {
            ni.value = '';
            ci.value = this.outpatientCats[0] || (this.inpatientCats.length > 0 ? this.inpatientCats[0] : 'General'); // Default to first available cat
            pi.value = '';
            ti.value = 'Medicine';
            (document.getElementById('entryModalLabel') as HTMLElement).innerText = 'ADD NEW DATABASE RECORD';
        }
    }
    this.entryModal?.show();
  }

  public savePricingEntry() {
    const n = (document.getElementById('entry-name') as HTMLInputElement).value.trim();
    const c = (document.getElementById('entry-cat') as HTMLSelectElement).value;
    const p = parseFloat((document.getElementById('entry-price') as HTMLInputElement).value);
    const t = (document.getElementById('entry-type') as HTMLSelectElement).value;
    if (!n || isNaN(p) || p < 0) {
      Swal.fire({
        icon: 'error',
        title: 'Input Error',
        text: 'Please provide a valid name and a non-negative price.',
        background: '#121214', color: '#fff'
      });
      return;
    }

    if (!this.inventory[c]) {
      this.inventory[c] = [];
    }

    if (this.activeEditItem) {
        const oldCat = this.activeEditItem.category;
        
        // Remove from old category if category changed
        if (oldCat && oldCat !== c && this.inventory[oldCat]) {
          this.inventory[oldCat] = this.inventory[oldCat].filter(item => item.id !== this.activeEditItem!.id);
          if (this.inventory[oldCat].length === 0) {
            delete this.inventory[oldCat];
          }
        }

        // Find and update item in the correct (potentially new) category
        const targetCategoryItems = this.inventory[c];
        const existingItemIndex = targetCategoryItems.findIndex(item => item.id === this.activeEditItem!.id);

        if (existingItemIndex > -1) {
            targetCategoryItems[existingItemIndex] = { ...this.activeEditItem, name: n, category: c, price: p, type: t };
        } else {
            // If item moved categories or wasn't found (e.g., ID conflict, though unlikely with filter above)
            this.inventory[c].push({ ...this.activeEditItem, name: n, category: c, price: p, type: t });
        }
        Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'RECORD UPDATED', showConfirmButton: false, timer: 1200, background: '#121214', color: '#fff' });

    } else {
      const newItem: InventoryItem = { id: this.nextItemId++, name: n, price: p, type: t, category: c };
      this.inventory[c].push(newItem);
      Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'RECORD ADDED', showConfirmButton: false, timer: 1200, background: '#121214', color: '#fff' });
    }

    this.outpatientCats = Object.keys(this.inventory).sort(); // Re-sort outpatient categories
    this.renderPricing();
    this.populatePricingFilters(); // Update dropdown
    this.entryModal?.hide();
    this.activeEditItem = null; // Clear active edit item after saving
  }

  public deletePricingEntry(itemToDelete: InventoryItem) {
    Swal.fire({ 
        title: 'DELETE RECORD?', 
        text: `Are you sure you want to delete "${itemToDelete.name}" from ${itemToDelete.category || 'N/A'}? This cannot be undone.`, 
        icon: 'warning', 
        showCancelButton: true, 
        confirmButtonText: 'YES, DELETE', 
        cancelButtonText: 'CANCEL',
        background: '#121214', color: '#fff',
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#475569'
    }).then((res: any) => { 
        if (res.isConfirmed) {
            const cat = itemToDelete.category;
            if (cat && this.inventory[cat]) {
                this.inventory[cat] = this.inventory[cat].filter(item => item.id !== itemToDelete.id);
                // Clean up empty category
                if (this.inventory[cat].length === 0) {
                    delete this.inventory[cat];
                }
                this.outpatientCats = Object.keys(this.inventory).sort();
                this.renderPricing();
                this.populatePricingFilters();
                Swal.fire({ icon: 'success', title: 'DELETED!', text: `"${itemToDelete.name}" has been removed.`, background: '#121214', color: '#fff' });
            }
        } 
    });
  }

  public exportDatabase() {
    const data = JSON.stringify(Object.values(this.inventory).flat(), null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mch_db_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    Swal.fire({ 
        toast: true, position: 'top-end', icon: 'success', title: 'DATABASE EXPORTED', showConfirmButton: false, timer: 1500, background: '#121214', color: '#fff' 
    });
  }

  public importDatabase(event: Event) {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) {
      Swal.fire({ icon: 'error', title: 'No file selected', text: 'Please choose a JSON file to import.', background: '#121214', color: '#fff' });
      return;
    }

    const file = input.files[0];
    if (file.type !== 'application/json') {
      Swal.fire({ icon: 'error', title: 'Invalid file type', text: 'Please select a .json file.', background: '#121214', color: '#fff' });
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const fileContent = e.target?.result as string;
        const importedData: InventoryItem[] = JSON.parse(fileContent);

        if (!Array.isArray(importedData) || importedData.some(item => !item.name || !item.price)) {
          throw new Error('Invalid JSON structure. Expected an array of items with name and price.');
        }

        Swal.fire({
          title: 'Import Database?',
          text: 'This will REPLACE your current pricing database. Are you sure?',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonText: 'YES, IMPORT',
          cancelButtonText: 'CANCEL',
          background: '#121214', color: '#fff',
          confirmButtonColor: '#10b981',
          cancelButtonColor: '#475569'
        }).then(async (result: any) => {
          if (result.isConfirmed) {
            this.inventory = {}; // Clear current inventory
            this.nextItemId = 1; // Reset ID counter

            importedData.forEach(item => {
              const cat = item.category || "General";
              if (!this.inventory[cat]) this.inventory[cat] = [];
              if (item.id === undefined || item.id === null) {
                item.id = this.nextItemId++;
              } else if (item.id >= this.nextItemId) {
                this.nextItemId = item.id + 1;
              }
              this.inventory[cat].push(item);
            });

            this.outpatientCats = Object.keys(this.inventory).sort();
            this.renderPricing();
            this.populatePricingFilters();
            Swal.fire({ icon: 'success', title: 'Import Successful!', text: 'Your pricing database has been updated.', background: '#121214', color: '#fff' });
          } else {
            Swal.fire({ icon: 'info', title: 'Import Cancelled', text: 'Your database remains unchanged.', background: '#121214', color: '#fff' });
          }
        });

      } catch (error: any) {
        console.error('Error importing database:', error);
        Swal.fire({ icon: 'error', title: 'Import Failed', text: `Could not process file: ${error.message || 'Invalid JSON format.'}`, background: '#121214', color: '#fff' });
      } finally {
        input.value = ''; // Clear the input so same file can be selected again
      }
    };
    reader.readAsText(file);
  }

  public finalize() {
    if (this.bill.length === 0) return;
    const prefix = this.currentView === 'outpatient' ? 'op' : 'ip';
    const total = document.getElementById(`${prefix}-total-val`)!.innerText;
    Swal.fire({ 
        title: 'COMMIT STATEMENT?', text: `Total: ৳ ${total}`, icon: 'question', showCancelButton: true, confirmButtonText: 'YES', background: '#121214', color: '#fff' 
    }).then((res: any) => { 
        if (res.isConfirmed) { this.clearBill(); Swal.fire({ icon: 'success', title: 'COMMITTED TO SERVER', background: '#121214', color: '#fff' }); } 
    });
  }
}

const app = new MediBillApp();
(window as any).app = app;